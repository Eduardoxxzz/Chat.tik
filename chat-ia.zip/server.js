import express from 'express';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(express.json());
app.use(express.static('public'));

const API_KEY = process.env.GROQ_API_KEY;
const PORT = process.env.PORT || 3000;

// Rota principal do chat com STREAMING
app.post('/api/chat', async (req, res) => {
  const { mensagens } = req.body;

  if (!mensagens || !Array.isArray(mensagens)) {
    return res.status(400).json({ erro: 'Formato inválido' });
  }

  // Configura headers para streaming (SSE)
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  try {
    const resposta = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`
      },
      body: JSON.stringify({
                        model: 'openai/gpt-oss-20b',
        messages: [
          { role: 'system', content: 'Você é um assistente amigável, responde em português do Brasil, de forma clara e direta.' },
          ...mensagens
        ],
        stream: true,
        temperature: 0.7
      })
    });

    if (!resposta.ok) {
      const erro = await resposta.text();
      res.write(`data: ${JSON.stringify({ erro })}\n\n`);
      return res.end();
    }

    // Lê o stream da IA e repassa pedaço por pedaço
    const reader = resposta.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const linhas = buffer.split('\n');
      buffer = linhas.pop();

      for (const linha of linhas) {
        if (!linha.startsWith('data: ')) continue;
        const dados = linha.slice(6).trim();
        if (dados === '[DONE]') continue;

        try {
          const json = JSON.parse(dados);
          const pedaco = json.choices?.[0]?.delta?.content;
          if (pedaco) {
            res.write(`data: ${JSON.stringify({ pedaco })}\n\n`);
          }
        } catch (e) {
          // ignora pedaços inválidos
        }
      }
    }

    res.write('data: [DONE]\n\n');
    res.end();

  } catch (erro) {
    console.error('Erro:', erro);
    res.write(`data: ${JSON.stringify({ erro: 'Falha ao conectar com a IA' })}\n\n`);
    res.end();
  }
});

app.listen(PORT, () => {
  console.log(`✅ Chat IA rodando em http://localhost:${PORT}`);
});
