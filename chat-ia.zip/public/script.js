const form = document.getElementById('form');
const input = document.getElementById('input');
const mensagensEl = document.getElementById('mensagens');
const limpar = document.getElementById('limpar');
const enviarBtn = document.getElementById('enviar');

// Histórico da conversa (mantém contexto)
let historico = [];
let enviando = false;

// Ajusta altura do textarea automaticamente
input.addEventListener('input', () => {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 150) + 'px';
});

// Enter envia, Shift+Enter quebra linha
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    form.requestSubmit();
  }
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (enviando) return;

  const texto = input.value.trim();
  if (!texto) return;

  input.value = '';
  input.style.height = 'auto';
  enviando = true;
  enviarBtn.disabled = true;

  // 1. Mostra mensagem do usuário
  adicionarMensagem(texto, 'usuario');
  historico.push({ role: 'user', content: texto });

  // 2. Cria bolha vazia para a IA
  const balaoIA = adicionarMensagem('', 'ia');
  balaoIA.classList.add('digitando');

  try {
    // 3. Envia para o backend
    const resposta = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mensagens: historico })
    });

    if (!resposta.ok) throw new Error('Erro na API');

    // 4. Lê o stream (resposta pedaço por pedaço)
    const reader = resposta.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let textoCompleto = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const linhas = buffer.split('\n\n');
      buffer = linhas.pop();

      for (const linha of linhas) {
        if (!linha.startsWith('data: ')) continue;
        const dados = linha.slice(6).trim();
        if (dados === '[DONE]') continue;

        try {
          const json = JSON.parse(dados);
          if (json.pedaco) {
            textoCompleto += json.pedaco;
            balaoIA.textContent = textoCompleto;
            mensagensEl.scrollTop = mensagensEl.scrollHeight;
          }
          if (json.erro) {
            balaoIA.textContent = '❌ ' + json.erro;
          }
        } catch {}
      }
    }

    // Salva resposta no histórico
    balaoIA.classList.remove('digitando');
    historico.push({ role: 'assistant', content: textoCompleto });

  } catch (erro) {
    balaoIA.classList.remove('digitando');
    balaoIA.textContent = '❌ Erro ao conectar com a IA.';
    console.error(erro);
  } finally {
    enviando = false;
    enviarBtn.disabled = false;
    input.focus();
  }
});

// Adiciona uma bolha de mensagem na tela
function adicionarMensagem(texto, tipo) {
  const div = document.createElement('div');
  div.className = `mensagem ${tipo}`;
  const balao = document.createElement('div');
  balao.className = 'balao';
  balao.textContent = texto;
  div.appendChild(balao);
  mensagensEl.appendChild(div);
  mensagensEl.scrollTop = mensagensEl.scrollHeight;
  return balao;
}

// Limpar conversa
limpar.addEventListener('click', () => {
  historico = [];
  mensagensEl.innerHTML = '';
  adicionarMensagem('Olá! 👋 Sou uma IA. Pergunte qualquer coisa!', 'ia');
  input.focus();
});

input.focus();